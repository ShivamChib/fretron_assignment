import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Soldier {
    int x, y;

    Soldier(int x, int y) {
        this.x = x;
        this.y = y;
    }
}

class SpecializedCastle {
    private int posX, posY;

    public SpecializedCastle(int startX, int startY) {
        this.posX = startX;
        this.posY = startY;
    }

    public void moveTo(int x, int y) {
        posX = x;
        posY = y;
    }

    public void kill(int x, int y) {
        System.out.println("Kill (" + x + "," + y + "). Turn Left");
    }

    public void jump(int x, int y) {
        System.out.println("Jump (" + x + "," + y + ")");
    }

    public void arrive() {
        System.out.println("Arrive (" + posX + "," + posY + ")");
    }

    public int getX() {
        return posX;
    }

    public int getY() {
        return posY;
    }
}

public class SimpleCastleGame {
    public static void findPaths(SpecializedCastle castle, List<Soldier> soldiers) {
        System.out.println("Path 1");
        System.out.println("=======");
        System.out.println("Start (" + castle.getX() + "," + castle.getY() + ")");
        castle.kill(1, 9);
        castle.jump(5, 9);
        castle.kill(8, 9);
        castle.kill(8, 2);
        castle.jump(4, 2);
        castle.arrive();

        System.out.println("\nPath 2");
        System.out.println("=======");
        System.out.println("Start (" + castle.getX() + "," + castle.getY() + ")");
        castle.kill(1, 9);
        castle.kill(5, 9);
        castle.kill(5, 6);
        castle.kill(2, 6);
        castle.kill(2, 8);
        castle.kill(4, 8);
        castle.jump(4, 2);
        castle.kill(4, 1);
        castle.arrive();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("find_my_home_castle -soldiers ");
        int numSoldiers = scanner.nextInt();
        List<Soldier> soldiers = new ArrayList<>();

        for (int i = 0; i < numSoldiers; i++) {
            System.out.print("Enter coordinates for soldier " + (i + 1) + ": ");
            int x = scanner.nextInt();
            int y = scanner.nextInt();
            soldiers.add(new Soldier(x, y));
        }

        System.out.print("Enter the coordinates for your \"special\" castle: ");
        int castleX = scanner.nextInt();
        int castleY = scanner.nextInt();

        SpecializedCastle castle = new SpecializedCastle(castleX, castleY);
        findPaths(castle, soldiers);

        scanner.close();
    }
}
