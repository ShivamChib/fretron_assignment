library(ggplot2)

flights <- list(
  "Flight 1" = data.frame(x = c(1, 2, 3), y = c(1, 2, 3)),
  "Flight 2" = data.frame(x = c(1, 2, 3), y = c(1, 4, 2)),
  "Flight 3" = data.frame(x = c(1, 4, 3), y = c(1, 2, 4))
)

plot <- ggplot() + 
  xlim(0, 5) + 
  ylim(0, 5) +
  labs(title = "Flight Paths", x = "X Coordinate", y = "Y Coordinate") +
  theme_minimal()


for (flight_name in names(flights)) {
  flight_data <- flights[[flight_name]]
  plot <- plot + 
    geom_line(data = flight_data, aes(x = x, y = y), 
              color = sample(colors(), 1), size = 1) +  
    geom_point(data = flight_data, aes(x = x, y = y), 
               color = "black", size = 3) + 
    geom_text(data = flight_data, aes(x = x, y = y, label = flight_name), 
              vjust = -1, size = 3, check_overlap = TRUE)
}

plot <- plot + 
  geom_point(aes(x = 1, y = 1), color = "red", size = 4) + 
  annotate("text", x = 1, y = 1, label = "Start", vjust = 1.5, color = "red")

print(plot)

