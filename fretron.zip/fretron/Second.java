import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Apple {
    int weight;
    boolean allocated;

    Apple(int weight) {
        this.weight = weight;
        this.allocated = false;
    }
}

public class Second
 {

    public static void distributeApples(List<Apple> apples, int ramShare, int shamShare, int rahimShare) {
        List<Apple> ramApples = new ArrayList<>();
        List<Apple> shamApples = new ArrayList<>();
        List<Apple> rahimApples = new ArrayList<>();
        int totalWeight = 0;

        for (Apple apple : apples) {
            totalWeight += apple.weight;
        }

        int ramTarget = (ramShare * totalWeight) / 100;
        int shamTarget = (shamShare * totalWeight) / 100;
        int rahimTarget = (rahimShare * totalWeight) / 100;

    
        for (Apple apple : apples) {
            if (!apple.allocated) {
                if (ramTarget > 0 && ramTarget >= apple.weight) {
                    ramApples.add(apple);
                    ramTarget -= apple.weight;
                } else if (shamTarget > 0 && shamTarget >= apple.weight) {
                    shamApples.add(apple);
                    shamTarget -= apple.weight;
                } else if (rahimTarget > 0 && rahimTarget >= apple.weight) {
                    rahimApples.add(apple);
                    rahimTarget -= apple.weight;
                }
            }
        }

        System.out.println("Distribution Result:");
        System.out.print("Ram: ");
        for (Apple apple : ramApples) {
            System.out.print(apple.weight + " ");
        }
        System.out.print("\nSham: ");
        for (Apple apple : shamApples) {
            System.out.print(apple.weight + " ");
        }
        System.out.print("\nRahim: ");
        for (Apple apple : rahimApples) {
            System.out.print(apple.weight + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Apple> apples = new ArrayList<>();
        int weight;

        System.out.print("Enter apple weight in grams (-1 to stop): ");
        while (true) {
            weight = scanner.nextInt();
            if (weight == -1) break;
            apples.add(new Apple(weight));
        }

        int ramShare = 50;
        int shamShare = 30;
        int rahimShare = 20;

        distributeApples(apples, ramShare, shamShare, rahimShare);

        scanner.close();
    }
}
